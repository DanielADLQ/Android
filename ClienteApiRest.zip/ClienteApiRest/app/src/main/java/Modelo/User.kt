package Modelo

data class User(
    val body: String,
    val id: Int,
    val title: String,
    val userId: Int
)
