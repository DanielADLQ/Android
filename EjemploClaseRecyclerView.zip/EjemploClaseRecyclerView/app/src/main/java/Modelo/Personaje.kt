package Modelo

data class Personaje(var nombre:String, var tipo:String, var imagen:String)
