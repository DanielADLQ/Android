package Modelo

data class Persona(var nombre:String, var edad:Int)