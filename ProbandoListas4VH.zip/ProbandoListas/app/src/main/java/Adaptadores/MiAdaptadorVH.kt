package Adaptadores

import android.app.Activity
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.probandolistas.R

class MiAdaptadorVH : ArrayAdapter<Int> {
    private var context: Activity
    private var resource: Int
    private var valores: Array<Int>? = null
    private var seleccionado:Int = 0

    constructor(context: Activity, resource: Int, valores: Array<Int>, seleccionado:Int) : super(context, resource) {
        this.context = context
        this.resource = resource
        this.valores = valores
        this.seleccionado = seleccionado
    }

    override fun getCount(): Int {
        return this.valores?.size!!
    }

    override fun getItem(position: Int): Int? {
        return this.valores?.get(position)
    }

    /**
     * Este método se carga para cada elemento de la lista. Tanta llamada a findviewbyid hace que se pueda
     * ralentizar y que caiga el rendimiento.
     */
    /**
     * Este método se carga para cada elemento de la lista. Tanta llamada a findviewbyid hace que se pueda
     * ralentizar y que caiga el rendimiento.
     */
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view: View? = convertView
        var holder = ViewHolder()
        if (view == null) {
            if (this.context!=null) {
                view = context.layoutInflater.inflate(this.resource, null)
                holder.txtItem = view.findViewById(R.id.txtItem)
                holder.imagen = view.findViewById(R.id.imMiImagen)
                view.tag = holder
            }
        }
        else {
            holder = view?.tag as ViewHolder
        }
        var valor: Int = this.valores!![position]
        holder.txtItem?.text  = valor.toString()
        if (position == seleccionado) {
            with(holder.txtItem) { this?.setTextColor(android.graphics.Color.RED)
                this?.setBackgroundResource(com.example.probandolistas.R.color.teal_700)}
            with(holder.imagen) {
                this?.setImageResource(com.example.probandolistas.R.drawable.ic_baseline_perm_identity_24)
            }
        }
        return view!!
    }

    class ViewHolder(){
        var txtItem:TextView? = null
        var imagen:ImageView? = null
    }
}