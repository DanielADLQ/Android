package com.example.consultasfirestore

interface MyCallBack {
    fun onCallback(value: ArrayList<User>)
}