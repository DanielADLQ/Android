package com.example.consultasfirestore

data class User(var born:String, var first:String, var last:String, val roles: ArrayList<Int>)

